package main

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"sync"
	"time"
)

var countryNameZH = map[string]string{
	"JP": "日本", "KR": "韩国", "US": "美国", "HK": "中国香港", "TW": "中国台湾",
	"SG": "新加坡", "GB": "英国", "DE": "德国", "FR": "法国", "CA": "加拿大",
	"AU": "澳大利亚", "NL": "荷兰", "MY": "马来西亚", "PH": "菲律宾", "ID": "印尼",
	"TH": "泰国", "VN": "越南", "IN": "印度", "RU": "俄罗斯", "BR": "巴西",
	"TR": "土耳其", "IT": "意大利", "ES": "西班牙", "SE": "瑞典", "CH": "瑞士",
	"NO": "挪威", "FI": "芬兰", "PL": "波兰", "CZ": "捷克", "AT": "奥地利",
	"GLOBAL": "全球", "EDU": "海外高校学术网", "GOV": "政府公共机构专网",
}

// subCountryRank 定义订阅导出与客户端展示的核心国家权重：
// 热门国家在前（美国 3 节点在前，日本 3 节点紧随其后，港台新韩英德加法澳荷等依次排列），冷门国家在后。
var subCountryRank = map[string]int{
	"US":  1,  // 美国 (优先最前)
	"JP":  2,  // 日本 (紧随其后)
	"HK":  3,  // 中国香港
	"TW":  4,  // 中国台湾
	"SG":  5,  // 新加坡
	"KR":  6,  // 韩国
	"GB":  7,  // 英国
	"DE":  8,  // 德国
	"CA":  9,  // 加拿大
	"FR":  10, // 法国
	"AU":  11, // 澳大利亚
	"NL":  12, // 荷兰
	"GOV": 13, // 政府公共机构专网
	"EDU": 14, // 海外高校学术网
	"VN":  15, // 越南
	"TH":  16, // 泰国
	"MY":  17, // 马来西亚
	"PH":  18, // 菲律宾
	"ID":  19, // 印尼
	"IN":  20, // 印度
	"RU":  21, // 俄罗斯
	"BR":  22, // 巴西
	"TR":  23, // 土耳其
	"IT":  24, // 意大利
	"ES":  25, // 西班牙
	"CH":  26, // 瑞士
	"SE":  27, // 瑞典
	"NO":  28, // 挪威
	"FI":  29, // 芬兰
	"PL":  30, // 波兰
	"CZ":  31, // 捷克
	"AT":  32, // 奥地利
}

func getSubCountryRank(cc string) int {
	cc = strings.ToUpper(strings.TrimSpace(cc))
	if r, ok := subCountryRank[cc]; ok {
		return r
	}
	return 999
}

// formatProxyName 构造纯净的订阅节点名称：[国旗Emoji] [企业/高校名称] (仅国旗表情，不含文字国家，不含"出口"字样，完全去除协议与端口)
func isServerDirectInbound(d *InboundDetail) bool {
	if d == nil {
		return false
	}
	b := strings.TrimSpace(d.BoundTo)
	if b != "" && !strings.EqualFold(b, "direct") && !strings.EqualFold(b, "none") {
		return false
	}
	r := strings.ToLower(strings.TrimSpace(d.Remark))
	return strings.Contains(r, "服务器直连") || strings.Contains(r, "server-direct")
}

func formatProxyName(countryCode, country, isp string) string {
	cc := strings.ToUpper(strings.TrimSpace(countryCode))
	flag := getFlagEmoji(cc)

	comp := strings.TrimSpace(isp)
	if strings.Contains(comp, "出口") {
		comp = strings.ReplaceAll(comp, "出口", "")
		comp = strings.TrimPrefix(comp, "-")
		comp = strings.TrimSpace(comp)
	}
	if comp == "" || strings.EqualFold(comp, "Public Proxy") || strings.EqualFold(comp, "Public Pool") || strings.EqualFold(comp, "VPN Gate") {
		if strings.Contains(strings.ToLower(isp), "tsukuba") || strings.EqualFold(cc, "JP") {
			comp = "筑波大学 VPN Gate"
		} else {
			comp = "优质网络"
		}
	}
	runes := []rune(comp)
	if len(runes) > 28 {
		comp = string(runes[:26]) + "..."
	}

	return fmt.Sprintf("%s %s", flag, comp)
}

// apiCredToken 供已登录 Web 界面的管理员获取口令，方便一键生成带 token 的聚合订阅链接
func apiCredToken(a *Auth) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{
			"token": a.SubscriptionToken(),
		})
	}
}

// apiSubscriptionSettings 管理独立订阅密钥、流量上限和到期时间。
// 流量/到期策略会同步写入 3x-ui 的客户端字段，真正由 Xray/3x-ui 执行。
func apiSubscriptionSettings(a *Auth, m *Manager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		cur := getSubscriptionSettings()
		if r.Method == http.MethodPost {
			var in struct {
				ResetToken bool     `json:"reset_token"`
				QuotaGB    *float64 `json:"quota_gb"`
				ExpireAt   *int64   `json:"expire_at"`
				ExpireDays *int     `json:"expire_days"`
			}
			if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
				writeJSON(w, http.StatusBadRequest, map[string]string{"error": "请求格式错误"})
				return
			}
			if in.QuotaGB != nil {
				cur.QuotaGB = *in.QuotaGB
			}
			if in.ExpireAt != nil {
				cur.ExpireAt = *in.ExpireAt
			}
			if in.ExpireDays != nil {
				if *in.ExpireDays <= 0 {
					cur.ExpireAt = 0
				} else {
					cur.ExpireAt = time.Now().Add(time.Duration(*in.ExpireDays) * 24 * time.Hour).UnixMilli()
				}
			}
			if err := setSubscriptionSettings(cur); err != nil {
				writeJSON(w, http.StatusBadRequest, map[string]string{"error": err.Error()})
				return
			}
			if in.ResetToken {
				if _, err := a.ResetSubscriptionToken(); err != nil {
					writeJSON(w, http.StatusInternalServerError, map[string]string{"error": err.Error()})
					return
				}
			}
			if p, err := openPanel(); err == nil && p != nil {
				if err := p.SetAllClientLimits(cur.QuotaGB, cur.ExpireAt, m.Tunnels()); err != nil {
					writeJSON(w, http.StatusBadGateway, map[string]string{"error": "订阅配额已保存，但同步到后端失败: " + err.Error()})
					return
				}
			}
		}
		cur = getSubscriptionSettings()
		writeJSON(w, http.StatusOK, map[string]any{
			"token":            a.SubscriptionToken(),
			"quota_gb":         cur.QuotaGB,
			"expire_at":        cur.ExpireAt,
			"quota_unlimited":  cur.QuotaGB <= 0,
			"expire_unlimited": cur.ExpireAt <= 0,
		})
	}
}

// apiSubscription 生成聚合订阅链接，支持 Base64 通用订阅与 Clash / Mihomo 配置订阅
func apiSubscription(m *Manager, a *Auth) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		policy := getSubscriptionSettings()
		if policy.ExpireAt > 0 && time.Now().UnixMilli() >= policy.ExpireAt {
			http.Error(w, "订阅已到期", http.StatusForbidden)
			return
		}
		// 订阅被请求时再对账一次，确保“服务器直连 · 本机”已经真实存在，
		// 即使智能编排尚未跑完，直连节点也必须进入订阅。
		m.reconcilePanelBindings()
		host := publicHost(r)
		format := strings.ToLower(r.URL.Query().Get("format"))
		ua := strings.ToLower(r.UserAgent())
		isClash := format == "clash" ||
			strings.Contains(ua, "clash") ||
			strings.Contains(ua, "mihomo") ||
			strings.Contains(ua, "meta")
		isQuanX := format == "quanx" ||
			strings.Contains(ua, "quantumult") ||
			strings.Contains(ua, "quanx")

		// 建立已连接出站绑定的映射：支持 HostName, sanitizeTag, IP, slot 等全方位匹配
		tunnels := m.Tunnels()
		boundTunnel := make(map[string]*Tunnel)
		var upTunnels []*Tunnel
		for _, t := range tunnels {
			if t.Status == "up" {
				upTunnels = append(upTunnels, t)
				boundTunnel[t.Node.HostName] = t
				boundTunnel[sanitizeTag(t.Node.HostName)] = t
				if t.Node.IP != "" {
					boundTunnel[t.Node.IP] = t
				}
				boundTunnel[fmt.Sprintf("exit-%d", t.Slot)] = t
				boundTunnel[fmt.Sprintf("slot-%d", t.Slot)] = t
			}
		}

		findTunnel := func(boundTo string) *Tunnel {
			boundTo = strings.TrimSpace(boundTo)
			if boundTo == "" || strings.EqualFold(boundTo, "direct") || strings.EqualFold(boundTo, "none") {
				return nil
			}
			if t, ok := boundTunnel[boundTo]; ok && t != nil {
				return t
			}
			clean := sanitizeTag(boundTo)
			if t, ok := boundTunnel[clean]; ok && t != nil {
				return t
			}
			for _, t := range upTunnels {
				s := sanitizeTag(t.Node.HostName)
				if len(s) >= 3 && (strings.Contains(boundTo, s) || strings.Contains(s, boundTo)) {
					return t
				}
				if t.Node.IP != "" && strings.Contains(boundTo, t.Node.IP) {
					return t
				}
			}
			return nil
		}

		// 订阅始终以当前运行态为准：禁止 CDN/浏览器缓存旧节点，且用 ETag 做条件刷新。
		var etagSeed strings.Builder
		for _, t := range m.Tunnels() {
			if t.Status == "up" {
				etagSeed.WriteString(fmt.Sprintf("%d|%s|%s|%s;", t.Slot, t.Node.HostName, t.Node.IP, t.ExitIP))
			}
		}
		etag := fmt.Sprintf(`"%x"`, sha256.Sum256([]byte(etagSeed.String())))
		w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
		w.Header().Set("Pragma", "no-cache")
		w.Header().Set("Expires", "0")
		w.Header().Set("ETag", etag)
		if strings.TrimSpace(r.Header.Get("If-None-Match")) == etag {
			w.WriteHeader(http.StatusNotModified)
			return
		}

		// 收集运行中的出口节点与绑定的 3x-ui 入站（并发极速查询，严格 1:1 实时同步，绝不重复生成，永不超时）
		coveredSlots := make(map[int]bool)
		var validDetails []*InboundDetail
		var validMu sync.Mutex

		p, err := openPanel()
		if err == nil && p != nil {
			inbounds, _ := p.Inbounds(nil)
			var wg sync.WaitGroup
			for _, ib := range inbounds {
				wg.Add(1)
				go func(id int) {
					defer wg.Done()
					d, dErr := p.InboundDetail(id, host)
					if dErr == nil && d != nil {
						t := findTunnel(d.BoundTo)
						validMu.Lock()
						if isServerDirectInbound(d) {
							validDetails = append(validDetails, d)
						} else if t != nil && !coveredSlots[t.Slot] {
							coveredSlots[t.Slot] = true
							validDetails = append(validDetails, d)
						}
						validMu.Unlock()
					}
				}(ib.ID)
			}
			wg.Wait()
		}

		// 严格按国家权重排序：美国 3 节点在前，日本 3 节点紧随其后，热门国在前，冷门国在后
		sort.SliceStable(validDetails, func(i, j int) bool {
			t1 := findTunnel(validDetails[i].BoundTo)
			t2 := findTunnel(validDetails[j].BoundTo)
			var c1, c2 string
			s1, s2 := 0, 0
			if t1 != nil {
				c1 = strings.ToUpper(strings.TrimSpace(t1.Node.CountryCode))
				s1 = t1.Slot
			}
			if t2 != nil {
				c2 = strings.ToUpper(strings.TrimSpace(t2.Node.CountryCode))
				s2 = t2.Slot
			}
			r1 := getSubCountryRank(c1)
			r2 := getSubCountryRank(c2)
			if r1 != r2 {
				return r1 < r2
			}
			if c1 != c2 {
				return c1 < c2
			}
			return s1 < s2
		})

		// 排序独立出口隧道
		sort.SliceStable(upTunnels, func(i, j int) bool {
			c1 := strings.ToUpper(strings.TrimSpace(upTunnels[i].Node.CountryCode))
			c2 := strings.ToUpper(strings.TrimSpace(upTunnels[j].Node.CountryCode))
			r1 := getSubCountryRank(c1)
			r2 := getSubCountryRank(c2)
			if r1 != r2 {
				return r1 < r2
			}
			if c1 != c2 {
				return c1 < c2
			}
			return upTunnels[i].Slot < upTunnels[j].Slot
		})

		var allLinks []string
		seenLinks := make(map[string]int)
		makeUniqueLinkName := func(raw string) string {
			count := seenLinks[raw]
			seenLinks[raw] = count + 1
			if count > 0 {
				return fmt.Sprintf("%s (%d)", raw, count+1)
			}
			return raw
		}

		// 按排好的顺序生成已绑定入站的代理链接
		for _, d := range validDetails {
			t := findTunnel(d.BoundTo)
			if t == nil {
				if !isServerDirectInbound(d) {
					continue
				}
				for _, rawLink := range d.Links {
					idx := strings.LastIndex(rawLink, "#")
					cleanName := makeUniqueLinkName("🖥️ 服务器直连 · 本机")
					if idx != -1 {
						rawLink = rawLink[:idx] + "#" + url.QueryEscape(cleanName)
					} else {
						rawLink = rawLink + "#" + url.QueryEscape(cleanName)
					}
					allLinks = append(allLinks, rawLink)
				}
				continue
			}
			for _, rawLink := range d.Links {
				idx := strings.LastIndex(rawLink, "#")
				cleanName := makeUniqueLinkName(formatProxyName(t.Node.CountryCode, t.Node.Country, t.Node.ISP))
				if idx != -1 {
					rawLink = rawLink[:idx] + "#" + url.QueryEscape(cleanName)
				} else {
					rawLink = rawLink + "#" + url.QueryEscape(cleanName)
				}
				allLinks = append(allLinks, rawLink)
			}
		}

		// 仅对尚未绑定入站的独立出口隧道补充 SOCKS5 节点（纯净 [国旗Emoji] [企业/高校]，无协议与端口）
		for _, t := range upTunnels {
			if coveredSlots[t.Slot] {
				continue
			}
			cred := t.credential()
			label := makeUniqueLinkName(formatProxyName(t.Node.CountryCode, t.Node.Country, t.Node.ISP))
			s5Link := fmt.Sprintf("socks5://%s:%s@%s:%d#%s", cred.User, cred.Pass, host, t.Port, url.QueryEscape(label))
			allLinks = append(allLinks, s5Link)
		}

		// Subscription-Userinfo 与实际 3x-ui 客户端配额保持一致。
		// 未设置配额时使用 0，表示不限。
		totalBytes := int64(0)
		if policy.QuotaGB > 0 {
			totalBytes = int64(policy.QuotaGB * 1024 * 1024 * 1024)
		}
		expireSec := int64(0)
		if policy.ExpireAt > 0 {
			expireSec = policy.ExpireAt / 1000
		}
		w.Header().Set("Subscription-Userinfo", fmt.Sprintf("upload=0; download=0; total=%d; expire=%d", totalBytes, expireSec))
		w.Header().Set("Profile-Update-Interval", "12")

		if isClash {
			w.Header().Set("Content-Type", "text/yaml; charset=utf-8")
			w.Header().Set("Content-Disposition", "attachment; filename=\"fanout-clash.yaml\"")
			yamlContent := generateClashConfig(validDetails, upTunnels, host)
			_, _ = w.Write([]byte(yamlContent))
			return
		}

		if isQuanX {
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			w.Header().Set("Content-Disposition", "attachment; filename=\"fanout-quanx.txt\"")
			qxContent := generateQuanXConfig(validDetails, upTunnels, host)
			if r.URL.Query().Get("raw") == "1" {
				_, _ = w.Write([]byte(qxContent))
				return
			}
			b64 := base64.StdEncoding.EncodeToString([]byte(qxContent))
			_, _ = w.Write([]byte(b64))
			return
		}

		// 默认通用 Base64 订阅（适用于 Shadowrocket / V2RayN / Sing-box / NekoBox / Loon 等）
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.Header().Set("Content-Disposition", "attachment; filename=\"fanout.txt\"")
		body := strings.Join(allLinks, "\n")
		b64 := base64.StdEncoding.EncodeToString([]byte(body))
		_, _ = w.Write([]byte(b64))
	}
}

// generateClashConfig 生成标准的 Clash / Mihomo YAML 订阅配置
func generateClashConfig(details []*InboundDetail, tunnels []*Tunnel, host string) string {
	var sb strings.Builder
	sb.WriteString("# Fanout 聚合代理订阅 - 自动路由出口\r\n")
	sb.WriteString(fmt.Sprintf("# 生成时间: %s\r\n", time.Now().Format("2006-01-02 15:04:05")))
	sb.WriteString("port: 7890\r\nsocks-port: 7891\r\nallow-lan: true\r\nmode: rule\r\nlog-level: info\r\nipv6: false\r\n\r\n")

	type proxyItem struct {
		name string
		yaml string
	}
	var proxies []proxyItem

	// 建立 boundTo 对应关系：支持 HostName, sanitizeTag, IP, slot 等全方位匹配
	boundTunnel := make(map[string]*Tunnel)
	for _, t := range tunnels {
		boundTunnel[t.Node.HostName] = t
		boundTunnel[sanitizeTag(t.Node.HostName)] = t
		if t.Node.IP != "" {
			boundTunnel[t.Node.IP] = t
		}
		boundTunnel[fmt.Sprintf("exit-%d", t.Slot)] = t
		boundTunnel[fmt.Sprintf("%d", t.Slot)] = t
	}
	findTunnel := func(boundTo string) *Tunnel {
		if boundTo == "" {
			if len(tunnels) == 1 {
				return tunnels[0]
			}
			return nil
		}
		if t, ok := boundTunnel[boundTo]; ok && t != nil {
			return t
		}
		clean := sanitizeTag(boundTo)
		if t, ok := boundTunnel[clean]; ok && t != nil {
			return t
		}
		for _, t := range tunnels {
			s := sanitizeTag(t.Node.HostName)
			if strings.Contains(boundTo, s) || strings.Contains(s, boundTo) {
				return t
			}
			if t.Node.IP != "" && strings.Contains(boundTo, t.Node.IP) {
				return t
			}
		}
		if len(tunnels) == 1 {
			return tunnels[0]
		}
		return nil
	}

	seenNames := make(map[string]int)
	makeUniqueName := func(raw string) string {
		count := seenNames[raw]
		seenNames[raw] = count + 1
		if count > 0 {
			return fmt.Sprintf("%s (%d)", raw, count+1)
		}
		return raw
	}

	// 1. 处理 3x-ui 入站（严格 1:1 绑定到运行中的出口）
	coveredSlots := make(map[int]bool)
	for _, d := range details {
		proto := strings.ToLower(d.Protocol)
		t := findTunnel(d.BoundTo)
		if t == nil || coveredSlots[t.Slot] {
			continue
		}
		coveredSlots[t.Slot] = true

		for _, c := range d.Clients {
			pName := makeUniqueName(formatProxyName(t.Node.CountryCode, t.Node.Country, t.Node.ISP))

			switch proto {
			case "vless":
				tlsBool := d.TLS == "tls" || d.TLS == "reality"
				netType := d.Network
				if netType == "" {
					netType = "tcp"
				}
				py := fmt.Sprintf("  - name: %q\r\n    type: vless\r\n    server: %q\r\n    port: %d\r\n    uuid: %q\r\n    udp: true\r\n    network: %q\r\n    tls: %v\r\n",
					pName, host, d.Port, c.ID, netType, tlsBool)
				if netType == "ws" {
					py += "    ws-opts:\r\n      path: \"/\"\r\n"
				}
				proxies = append(proxies, proxyItem{name: pName, yaml: py})

			case "vmess":
				tlsBool := d.TLS == "tls"
				netType := d.Network
				if netType == "" {
					netType = "tcp"
				}
				py := fmt.Sprintf("  - name: %q\r\n    type: vmess\r\n    server: %q\r\n    port: %d\r\n    uuid: %q\r\n    alterId: 0\r\n    cipher: auto\r\n    udp: true\r\n    network: %q\r\n    tls: %v\r\n",
					pName, host, d.Port, c.ID, netType, tlsBool)
				if netType == "ws" {
					py += "    ws-opts:\r\n      path: \"/\"\r\n"
				}
				proxies = append(proxies, proxyItem{name: pName, yaml: py})

			case "trojan":
				py := fmt.Sprintf("  - name: %q\r\n    type: trojan\r\n    server: %q\r\n    port: %d\r\n    password: %q\r\n    udp: true\r\n    sni: %q\r\n",
					pName, host, d.Port, c.ID, host)
				proxies = append(proxies, proxyItem{name: pName, yaml: py})

			case "shadowsocks":
				parts := strings.SplitN(c.ID, ":", 2)
				method := "aes-256-gcm"
				pwd := c.ID
				if len(parts) == 2 {
					method = strings.TrimSpace(parts[0])
					pwd = strings.TrimSpace(parts[1])
				}
				py := fmt.Sprintf("  - name: %q\r\n    type: ss\r\n    server: %q\r\n    port: %d\r\n    cipher: %q\r\n    password: %q\r\n    udp: true\r\n",
					pName, host, d.Port, method, pwd)
				proxies = append(proxies, proxyItem{name: pName, yaml: py})

			case "socks":
				py := fmt.Sprintf("  - name: %q\r\n    type: socks5\r\n    server: %q\r\n    port: %d\r\n    username: %q\r\n    password: %q\r\n    udp: true\r\n",
					pName, host, d.Port, c.Email, c.ID)
				proxies = append(proxies, proxyItem{name: pName, yaml: py})
			}
		}
	}

	// 2. 仅对未绑定入站的独立出口隧道补充 SOCKS5 节点（纯净 [国旗Emoji] [企业/高校]，无协议与端口）
	for _, t := range tunnels {
		if coveredSlots[t.Slot] {
			continue
		}
		cred := t.credential()
		pName := makeUniqueName(formatProxyName(t.Node.CountryCode, t.Node.Country, t.Node.ISP))
		py := fmt.Sprintf("  - name: %q\r\n    type: socks5\r\n    server: %q\r\n    port: %d\r\n    username: %q\r\n    password: %q\r\n    udp: true\r\n",
			pName, host, t.Port, cred.User, cred.Pass)
		proxies = append(proxies, proxyItem{name: pName, yaml: py})
	}

	if len(proxies) == 0 {
		py := fmt.Sprintf("  - name: %q\r\n    type: socks5\r\n    server: %q\r\n    port: 1080\r\n", "暂无可用节点，请在面板开启出口", host)
		proxies = append(proxies, proxyItem{name: "暂无可用节点，请在面板开启出口", yaml: py})
	}

	sb.WriteString("proxies:\r\n")
	for _, p := range proxies {
		sb.WriteString(p.yaml)
	}
	sb.WriteString("\r\n")

	sb.WriteString("proxy-groups:\r\n")
	sb.WriteString("  - name: \"⚡ 节点选择\"\r\n    type: select\r\n    proxies:\r\n      - \"🚀 自动优选\"\r\n")
	for _, p := range proxies {
		sb.WriteString(fmt.Sprintf("      - %q\r\n", p.name))
	}

	sb.WriteString("  - name: \"🚀 自动优选\"\r\n    type: url-test\r\n    url: http://www.gstatic.com/generate_204\r\n    interval: 300\r\n    tolerance: 50\r\n    proxies:\r\n")
	for _, p := range proxies {
		sb.WriteString(fmt.Sprintf("      - %q\r\n", p.name))
	}
	sb.WriteString("\r\n")

	sb.WriteString("rules:\r\n  - MATCH,⚡ 节点选择\r\n")
	return sb.String()
}

// generateQuanXConfig 生成标准的 Quantumult X 节点订阅配置 (原生 server_remote 规范)
func generateQuanXConfig(details []*InboundDetail, tunnels []*Tunnel, host string) string {
	var sb strings.Builder
	sb.WriteString("# Quantumult X 节点订阅 - 聚合出海出口\r\n")
	sb.WriteString(fmt.Sprintf("# 生成时间: %s\r\n", time.Now().Format("2006-01-02 15:04:05")))
	sb.WriteString("# 格式说明: Quantumult X 原生支持 SOCKS5 / Trojan / VMess / Shadowsocks；由于 QuanX 内核不支持 VLESS，VLESS 节点已自动标注\r\n\r\n")

	boundTunnel := make(map[string]*Tunnel)
	for _, t := range tunnels {
		boundTunnel[t.Node.HostName] = t
		boundTunnel[sanitizeTag(t.Node.HostName)] = t
		if t.Node.IP != "" {
			boundTunnel[t.Node.IP] = t
		}
		boundTunnel[fmt.Sprintf("exit-%d", t.Slot)] = t
		boundTunnel[fmt.Sprintf("%d", t.Slot)] = t
	}
	findTunnel := func(boundTo string) *Tunnel {
		if boundTo == "" {
			if len(tunnels) == 1 {
				return tunnels[0]
			}
			return nil
		}
		if t, ok := boundTunnel[boundTo]; ok && t != nil {
			return t
		}
		clean := sanitizeTag(boundTo)
		if t, ok := boundTunnel[clean]; ok && t != nil {
			return t
		}
		for _, t := range tunnels {
			s := sanitizeTag(t.Node.HostName)
			if strings.Contains(boundTo, s) || strings.Contains(s, boundTo) {
				return t
			}
			if t.Node.IP != "" && strings.Contains(boundTo, t.Node.IP) {
				return t
			}
		}
		if len(tunnels) == 1 {
			return tunnels[0]
		}
		return nil
	}

	seenNames := make(map[string]int)
	makeUniqueName := func(raw string) string {
		count := seenNames[raw]
		seenNames[raw] = count + 1
		if count > 0 {
			return fmt.Sprintf("%s (%d)", raw, count+1)
		}
		return raw
	}

	// 1. 处理 3x-ui 入站（严格 1:1 绑定到运行中的出口）
	coveredSlots := make(map[int]bool)
	for _, d := range details {
		proto := strings.ToLower(d.Protocol)
		t := findTunnel(d.BoundTo)
		if t == nil || coveredSlots[t.Slot] {
			continue
		}
		coveredSlots[t.Slot] = true

		for _, c := range d.Clients {
			pName := makeUniqueName(formatProxyName(t.Node.CountryCode, t.Node.Country, t.Node.ISP))

			switch proto {
			case "trojan":
				sb.WriteString(fmt.Sprintf("trojan = %s:%d, password=%s, over-tls=true, tls-verification=false, fast-open=false, udp-relay=true, tag=%s\r\n",
					host, d.Port, c.ID, pName))

			case "vmess":
				netType := strings.ToLower(d.Network)
				tlsOpt := ""
				if d.TLS == "tls" {
					tlsOpt = ", over-tls=true, tls-verification=false"
				}
				obfsOpt := ""
				if netType == "ws" {
					obfsOpt = ", obfs=ws, obfs-uri=/"
				}
				sb.WriteString(fmt.Sprintf("vmess = %s:%d, method=chacha20-ietf-poly1305, password=%s%s%s, fast-open=false, udp-relay=true, tag=%s\r\n",
					host, d.Port, c.ID, obfsOpt, tlsOpt, pName))

			case "shadowsocks":
				parts := strings.SplitN(c.ID, ":", 2)
				method := "aes-256-gcm"
				pwd := c.ID
				if len(parts) == 2 {
					method = strings.TrimSpace(parts[0])
					pwd = strings.TrimSpace(parts[1])
				}
				sb.WriteString(fmt.Sprintf("shadowsocks = %s:%d, method=%s, password=%s, fast-open=false, udp-relay=true, tag=%s\r\n",
					host, d.Port, method, pwd, pName))

			case "socks":
				if c.Email != "" && c.ID != "" {
					sb.WriteString(fmt.Sprintf("socks5 = %s:%d, username=%s, password=%s, fast-open=false, udp-relay=true, tag=%s\r\n",
						host, d.Port, c.Email, c.ID, pName))
				} else {
					sb.WriteString(fmt.Sprintf("socks5 = %s:%d, fast-open=false, udp-relay=true, tag=%s\r\n",
						host, d.Port, pName))
				}

			case "vless":
				sb.WriteString(fmt.Sprintf("; [QuanX 不支持 VLESS] %s (端口:%d) 采用 VLESS 协议。由于 Quantumult X 官方内核不支持 VLESS，建议在 3x-ui 面板中改用 Trojan 或 VMess。\r\n",
					pName, d.Port))
			}
		}
	}

	// 2. 仅对未绑定入站的独立出口隧道补充 SOCKS5 节点（纯净 [国旗Emoji] [企业/高校]，无协议与端口）
	for _, t := range tunnels {
		if coveredSlots[t.Slot] {
			continue
		}
		cred := t.credential()
		pName := makeUniqueName(formatProxyName(t.Node.CountryCode, t.Node.Country, t.Node.ISP))
		if cred.User != "" && cred.Pass != "" {
			sb.WriteString(fmt.Sprintf("socks5 = %s:%d, username=%s, password=%s, fast-open=false, udp-relay=true, tag=%s\r\n",
				host, t.Port, cred.User, cred.Pass, pName))
		} else {
			sb.WriteString(fmt.Sprintf("socks5 = %s:%d, fast-open=false, udp-relay=true, tag=%s\r\n",
				host, t.Port, pName))
		}
	}

	return sb.String()
}

// getFlagEmoji 把两位国家码（ISO 3166-1 alpha-2）转换为对应的国旗 Emoji
func getFlagEmoji(countryCode string) string {
	cc := strings.ToUpper(strings.TrimSpace(countryCode))
	if cc == "GOV" {
		return "🏛️"
	}
	if cc == "EDU" {
		return "🎓"
	}
	if len(cc) != 2 {
		return "🌐"
	}
	r1 := rune(cc[0]) - 'A' + 0x1F1E6
	r2 := rune(cc[1]) - 'A' + 0x1F1E6
	if r1 < 0x1F1E6 || r1 > 0x1F1FF || r2 < 0x1F1E6 || r2 > 0x1F1FF {
		return "🌐"
	}
	return string([]rune{r1, r2})
}
