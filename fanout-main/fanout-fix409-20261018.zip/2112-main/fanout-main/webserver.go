package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"sync"
	"time"
)

// webServer 管理 HTTP 监听，支持在运行时切换端口/监听地址而不重启进程。
// 切换端口或监听地址会新起一个 net.Listener，旧的优雅关闭。
type webServer struct {
	handler http.Handler

	mu      sync.Mutex
	applyMu sync.Mutex
	ln      net.Listener
	srv     *http.Server
	addr    string
}

func newWebServer(h http.Handler) *webServer {
	return &webServer{handler: h}
}

// serve 用当前 WebSettings 起第一个监听并阻塞。返回时说明监听彻底退出。
func (s *webServer) serve() error {
	cfg := getWebSettings()
	if err := s.reload(cfg); err != nil {
		return err
	}
	// 主 goroutine 就地阻塞，等监听被 reload 或退出替换。
	// 这里靠一个永不返回的 select 挂住：真正的 Serve 在 reload 里各自的 goroutine 跑。
	select {}
}

// reload 切换到新的监听地址：先探测能否绑上，绑得上再关旧的、启新的。
// 绑不上就保持旧监听不动，返回错误让调用方回报给用户。
func (s *webServer) reload(cfg WebSettings) error {
	addr := cfg.listenAddrString()

	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return fmt.Errorf("无法监听 %s：%w", addr, err)
	}

	s.mu.Lock()
	oldSrv := s.srv
	oldLn := s.ln
	srv := &http.Server{Handler: s.handler, ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 30 * time.Second, IdleTimeout: 60 * time.Second, MaxHeaderBytes: 1 << 20}
	s.srv = srv
	s.ln = ln
	s.addr = addr
	s.mu.Unlock()

	go func() {
		if err := srv.Serve(ln); err != nil && err != http.ErrServerClosed {
			log.Printf("HTTP 监听 %s 退出: %v", addr, err)
		}
	}()

	// 关掉旧监听。给正在处理的请求一点收尾时间，
	// 尤其是触发这次 reload 的那个请求本身要先把响应写完。
	if oldSrv != nil {
		go func() {
			time.Sleep(1 * time.Second)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			_ = oldSrv.Shutdown(ctx)
			_ = oldLn.Close()
		}()
	}

	log.Printf("管理界面监听已切换到 %s", addr)
	return nil
}

// applyWebSettings 校验、落盘并切换监听。任一步失败都不改动线上监听。
func (s *webServer) applyWebSettings(next WebSettings) error {
	s.applyMu.Lock()
	defer s.applyMu.Unlock()
	if err := validatePort(next.Port); err != nil {
		return err
	}
	norm, err := normalizeListenAddr(next.ListenAddr)
	if err != nil {
		return err
	}
	next.ListenAddr = norm

	cur := getWebSettings()
	// 端口和监听地址都没变就只需要确保已生效，避免无谓重绑
	if next.Port == cur.Port && next.ListenAddr == cur.ListenAddr {
		return nil
	}

	// Persist before touching the active listener. Roll back disk on bind failure.
	blob, err := json.MarshalIndent(next, "", "  ")
	if err != nil {
		return err
	}
	tmp := webSettingsPath + ".tmp"
	if err := os.WriteFile(tmp, blob, 0600); err != nil {
		return err
	}
	if err := os.Rename(tmp, webSettingsPath); err != nil {
		return err
	}
	if err := s.reload(next); err != nil {
		oldBlob, _ := json.MarshalIndent(cur, "", "  ")
		if writeErr := os.WriteFile(tmp, oldBlob, 0600); writeErr == nil {
			if restoreErr := os.Rename(tmp, webSettingsPath); restoreErr != nil {
				return fmt.Errorf("%v; 回滚设置失败: %w", err, restoreErr)
			}
		} else {
			return fmt.Errorf("%v; 回滚设置失败: %w", err, writeErr)
		}
		return err
	}

	webSettingsMu.Lock()
	webSettingsCur = next
	webSettingsMu.Unlock()
	return nil
}
